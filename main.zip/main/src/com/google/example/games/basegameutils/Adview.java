package com.google.example.games.basegameutils;



import android.content.Context;

public class Adview  {
	public static Context c;

	
}
