package com.awatech.fallingdigit;

import com.awatech.screens.DesktopGoogleServices;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;


public class Main {
	 public static void main (String[] arg) {
	        LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
	        config.title = "Falling Digit";
	        config.width = 380;
	        config.height = 480;
	        new LwjglApplication(new FDGame(new DesktopGoogleServices()), config);
	    }
}
